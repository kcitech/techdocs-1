#!/bin/bash

# since 2005/05/19  
# from [������ ���� ���� ���� �ǹ�]

IPTABLES=`which iptables`

$IPTABLES -t mangle -F
$IPTABLES -t nat -F
$IPTABLES -t filter -F


/sbin/iptables -F
/sbin/iptables -F INPUT
/sbin/iptables -F OUTPUT
/sbin/iptables -F FORWARD
/sbin/iptables -F -t mangle
/sbin/iptables -X
/sbin/iptables -F -t nat

$IPTABLES -P INPUT DROP
$IPTABLES -P FORWARD DROP
$IPTABLES -P OUTPUT ACCEPT

$IPTABLES -A INPUT -i lo -j ACCEPT
$IPTABLES -A OUTPUT -o lo -j ACCEPT

$IPTABLES -A INPUT -s 10.0.0.0/8 -j DROP
$IPTABLES -A INPUT -s 255.255.255.255/32 -j DROP
$IPTABLES -A INPUT -s 0.0.0.0/8 -j DROP
$IPTABLES -A INPUT -s 169.254.0.0/16 -j DROP
$IPTABLES -A INPUT -s 172.16.0.0/12 -j DROP
$IPTABLES -A INPUT -s 224.0.0.0/4 -j DROP
$IPTABLES -A INPUT -s 240.0.0.0/5 -j DROP
$IPTABLES -A INPUT -s 248.0.0.0/5 -j DROP

$IPTABLES -A FORWARD -s 10.0.0.0/8 -j DROP
$IPTABLES -A FORWARD -s 255.255.255.255/32 -j DROP
$IPTABLES -A FORWARD -s 0.0.0.0/8 -j DROP
$IPTABLES -A FORWARD -s 169.254.0.0/16 -j DROP
$IPTABLES -A FORWARD -s 172.16.0.0/12 -j DROP
$IPTABLES -A FORWARD -s 192.0.2.0/24 -j DROP
$IPTABLES -A FORWARD -s 224.0.0.0/4 -j DROP
$IPTABLES -A FORWARD -s 240.0.0.0/5 -j DROP
$IPTABLES -A FORWARD -s 248.0.0.0/5 -j DROP

# modify
MANAGER_IP=192.168.2.165
DST_SERVER_1=192.168.2.171
DST_SERVER_2=192.168.2.100

$IPTABLES -A FORWARD -s ${DST_SERVER_1} -m state --state NEW -j ACCEPT
$IPTABLES -A FORWARD -s ${DST_SERVER_2} -m state --state NEW -j ACCEPT

$IPTABLES -A OUTPUT -d 10.0.0.0/8 -j DROP
$IPTABLES -A OUTPUT -d 255.255.255.255/32 -j DROP
$IPTABLES -A OUTPUT -d 0.0.0.0/8 -j DROP
$IPTABLES -A OUTPUT -d 169.254.0.0/16 -j DROP
$IPTABLES -A OUTPUT -d 172.16.0.0/12 -j DROP
$IPTABLES -A OUTPUT -d 192.0.2.0/24 -j DROP
$IPTABLES -A OUTPUT -d 224.0.0.0/4 -j DROP
$IPTABLES -A OUTPUT -d 240.0.0.0/5 -j DROP
$IPTABLES -A OUTPUT -d 248.0.0.0/5 -j DROP

$IPTABLES -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
$IPTABLES -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
$IPTABLES -A FORWARD  -m state --state ESTABLISHED,RELATED -j ACCEPT
 
$IPTABLES -A INPUT -p TCP ! --syn -m state --state NEW -j DROP
$IPTABLES -A FORWARD -p TCP ! --syn -m state --state NEW -j DROP

$IPTABLES -A INPUT -p ALL -m state --state INVALID -j DROP 
$IPTABLES -A FORWARD -p ALL -m state --state INVALID -j DROP 
$IPTABLES -A OUTPUT -p ALL -m state --state INVALID -j DROP 

#######################################
# local host 
#######################################

#geoip
$IPTABLES -A INPUT -p TCP  -m geoip --src-cc CN -j LOG --log-prefix "[localhost:SRC CN DROP]"
$IPTABLES -A INPUT -p TCP  -m geoip --src-cc CN -j DROP

#connlimit
$IPTABLES -A INPUT -p tcp --syn --dport 80 -m connlimit --connlimit-above 10 -m recent --name locahost_TCP80MANY --set -j DROP
$IPTABLES -A INPUT -p tcp --syn --dport 80 -m connlimit --connlimit-above 10 -j DROP

#www/80
$IPTABLES -A INPUT -p TCP --sport 1024: -s $MANAGER_IP --dport 80 -m state --state NEW -j ACCEPT

#ftp/21

#ssh/22
$IPTABLES -A INPUT -p TCP --sport 1024: -s $MANAGER_IP --dport 22 -m state --state NEW -j ACCEPT

#smtp/25

#icmp
$IPTABLES -N ICMP_HANDLE
$IPTABLES -F ICMP_HANDLE
$IPTABLES -A ICMP_HANDLE -p ICMP --icmp-type echo-reply -j ACCEPT
$IPTABLES -A ICMP_HANDLE -p ICMP --icmp-type echo-request -j ACCEPT
$IPTABLES -A ICMP_HANDLE -p ICMP --icmp-type network-unreachable -m limit --limit 1/s --limit-burst 5 -j ACCEPT
$IPTABLES -A ICMP_HANDLE -p ICMP --icmp-type host-unreachable -m limit --limit 1/s --limit-burst 5 -j ACCEPT
$IPTABLES -A ICMP_HANDLE -p ICMP --icmp-type port-unreachable -m limit --limit 1/s --limit-burst 5 -j ACCEPT
$IPTABLES -A ICMP_HANDLE -p ICMP --icmp-type fragmentation-needed -m limit --limit 1/s --limit-burst 5 -j ACCEPT
$IPTABLES -A ICMP_HANDLE -p ICMP --icmp-type time-exceeded -m limit --limit 1/s --limit-burst 5 -j ACCEPT
$IPTABLES -A INPUT -s $MANAGER_IP -p ICMP -j ICMP_HANDLE

#tcp flags
$IPTABLES -N CHECK_FLAGS
$IPTABLES -F CHECK_FLAGS
$IPTABLES -A CHECK_FLAGS -p tcp --tcp-flags ALL FIN,URG,PSH -j DROP
$IPTABLES -A CHECK_FLAGS -p TCP --tcp-flags SYN,FIN SYN,FIN -j DROP
$IPTABLES -A CHECK_FLAGS -p TCP --tcp-flags SYN,RST SYN,RST -j DROP
$IPTABLES -A CHECK_FLAGS -p TCP --tcp-flags FIN,RST FIN,RST -j DROP
$IPTABLES -A CHECK_FLAGS -p TCp --tcp-flags ACK,FIN FIN -j DROP
$IPTABLES -A CHECK_FLAGS -p TCP --tcp-flags ACK,PSH PSH -j DROP
$IPTABLES -A CHECK_FLAGS -p TCP --tcp-flags ACK,URG URG -j DROP
$IPTABLES -A CHECK_FLAGS -p TCP --tcp-flags ALL FIN -j DROP
$IPTABLES -A CHECK_FLAGS -p TCP --tcp-flags ALL NONE -j DROP
$IPTABLES -A CHECK_FLAGS -p TCP --tcp-flags ALL PSH,FIN -j DROP
$IPTABLES -A CHECK_FLAGS -p TCP --syn --dport 113 -j REJECT --reject-with tcp-reset
$IPTABLES -A INPUT -p tcp -s $MANAGER_IP -j CHECK_FLAGS

#traceroute
$IPTABLES -N TRACEROUTE
$IPTABLES -F TRACEROUTE
$IPTABLES -A TRACEROUTE -m state --state NEW -p udp --dport 33000:38000 -j ACCEPT
$IPTABLES -A INPUT -p udp -s $MANAGER_IP -j TRACEROUTE


#######################################
# DST_SERVER_1 (192.168.2.171)
#######################################

#geoip
$IPTABLES -A FORWARD -p tcp -d ${DST_SERVER_1} -m geoip --src-cc CN -j LOG --log-prefix "[$DST_SERVER_1:SRC CN DROP]"
$IPTABLES -A FORWARD -p tcp -d ${DST_SERVER_1} -m geoip --src-cc CN -j DROP

#connlimit
$IPTABLES -A FORWARD -p tcp --syn -d ${DST_SERVER_1} --dport 80 -m connlimit --connlimit-above 10 -m recent --name ${DST_SERVER_1}_TCP80MANY --set -j DROP
$IPTABLES -A FORWARD -p tcp --syn -d ${DST_SERVER_1} --dport 80 -m connlimit --connlimit-above 10 -j DROP

#www/80
$IPTABLES -A FORWARD -p TCP -s $MANAGER_IP  --sport 1024: -d ${DST_SERVER_1} --dport 80 -m state --state NEW -j ACCEPT

#ftp/21
$IPTABLES -A FORWARD -p TCP -s $MANAGER_IP --sport 1024: -d ${DST_SERVER_1} --dport 21 -m state --state NEW -j ACCEPT 

#ssh/22
$IPTABLES -A FORWARD -p TCP -s $MANAGER_IP --sport 1024: -d ${DST_SERVER_1} --dport 22 -m state --state NEW -j ACCEPT

#smtp/25
$IPTABLES -A FORWARD -p TCP --sport 1024: --dport 25 -m state --state NEW -j ACCEPT

#vnc/5800,5900
#$IPTABLES -A FORWARD -p TCP -s $MANAGER_IP --sport 1024: -d 192.168.2.73 --dport 5800 -m state --state NEW -j ACCEPT
#$IPTABLES -A FORWARD -p TCP -s $MANAGER_IP --sport 1024: -d 192.168.2.73 --dport 5900 -m state --state NEW -j ACCEPT

#pop3/110
$IPTABLES -A FORWARD -p TCP -s $MANAGER_IP --sport 1024: -d ${DST_SERVER_1} --dport 110 -m state --state NEW -j ACCEPT

#mrtg/161
$IPTABLES -A FORWARD -p UDP -s $MANAGER_IP --sport 1024: --dport 161 -m state --state NEW -j ACCEPT

#icmp
$IPTABLES -A FORWARD -s $MANAGER_IP -d $DST_SERVER_1 -p ICMP -j ICMP_HANDLE

#tcp flags
$IPTABLES -A FORWARD -p tcp -s $MANAGER_IP -d $DST_SERVER_1 -j CHECK_FLAGS

#traceroute
$IPTABLES -A FORWARD -p udp -s $MANAGER_IP -d $DST_SERVER_1 -j TRACEROUTE


#######################################
# DST_SERVER_2 (192.168.2.100)
#######################################

$IPTABLES -A FORWARD -p TCP -d ${DST_SERVER_2} -m geoip ! --src-cc KR  -j DROP

#www/80
$IPTABLES -A FORWARD -p TCP -s $MANAGER_IP --sport 1024: -d ${DST_SERVER_2} --dport 80 -m state --state NEW -j ACCEPT

#ftp/21
#$IPTABLES -A FORWARD -p TCP -s $MANAGER_IP --sport 1024: -d ${DST_SERVER_2} --dport 21 -m state --state NEW -j ACCEPT 

#terminal/3389
$IPTABLES -A FORWARD -p TCP -s $MANAGER_IP --sport 1024: --dport 3389 -d ${DST_SERVER_2} -m state --state NEW -j ACCEPT

#icmp
$IPTABLES -A FORWARD -s $MANAGER_IP -d $DST_SERVER_2 -p ICMP -j ICMP_HANDLE

#tcp flags
$IPTABLES -A FORWARD -p tcp -s $MANAGER_IP -d $DST_SERVER_2 -j CHECK_FLAGS

#traceroute
$IPTABLES -A FORWARD -p udp -s $MANAGER_IP -d $DST_SERVER_2 -j TRACEROUTE
