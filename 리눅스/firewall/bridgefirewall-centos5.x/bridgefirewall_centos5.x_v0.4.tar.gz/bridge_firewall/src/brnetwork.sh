#!/bin/bash
 
BRCTL=`which brctl`
 
$BRCTL addbr br0
$BRCTL stp br0 on
$BRCTL addif br0 eth0
$BRCTL addif br0 eth1
$BRCTL setmaxage br0 4
$BRCTL setfd br0 4
ifconfig eth0 down
ifconfig eth0 down
ifconfig eth0 0.0.0.0 promisc up
ifconfig eth1 0.0.0.0 primisc up
ifconfig lo 127.0.0.1 up
ifconfig br0 192.168.2.178 promisc up
route add -host 127.0.0.1 dev lo
route add default gw 192.168.2.1
