#!/bin/bash

WORK_DIR=`pwd`

#delete
rm -rf $WORK_DIR/bridge-utils-1.4.jwpark
rm -rf $WORK_DIR/bridge-utils-1.4.jwpark.tar.gz

echo "###################################"
echo "##### 1. ebtables rpm install #####"
echo "###################################"
rpm -ivh ./src/ebtables-2.0.8-2.i386.rpm

echo "###################################"
echo "##### 2. brctl install        #####"
echo "###################################"
cp -v ./src/bridge-utils-1.4.jwpark.tar.gz .
tar xvfz bridge-utils-1.4.jwpark.tar.gz -C $WORK_DIR
cd $WORK_DIR/bridge-utils-1.4.jwpark
./configure && make
cp -v brctl/brctl /sbin/

echo "###################################"
echo "##### 3. check                #####"
echo "###################################"
ls -lhd /sbin/brctl

echo "###################################"
echo "##### 4. script setup         #####"
echo "###################################"
mkdir /root/bin/
cp -v $WORK_DIR/src/brnetwork.sh /root/bin/
cp -v $WORK_DIR/src/bridge_firewall.sh /root/bin/
cp -v $WORK_DIR/src/nofirewall.sh /root/bin/

echo "/root/bin/brnetwork.sh" >> /etc/rc.d/rc.local
echo "/root/bin/bridge_firewall.sh" >> /etc/rc.d/rc.local

#delete
rm -rf $WORK_DIR/bridge-utils-1.4.jwpark
rm -rf $WORK_DIR/bridge-utils-1.4.jwpark.tar.gz
