#!/bin/bash

dir=`pwd`
srcDir=/usr/src/redhat/SOURCES
krDir=/usr/src/kernels
ipt=iptables-1.3.5
kver=`uname -r`-`uname -m`
log=$dir/work/out.log

if [[ ! -f $log ]]
then
	touch $log
fi

cp -f $dir/src/* $dir/work/

echo "==============================="
echo "1. build geoip module at kernel"
echo "==============================="

cd $dir/work

echo "tar xvfz geoip-patch-o-matic-cent5.tar.gz"
tar xvfz geoip-patch-o-matic-cent5.tar.gz
cd ./geoip

echo "1.geoip-patch-o-matic-centos5 geoip-check" > $log
./geoip-check >> $log

echo ""
echo "ls /lib/modules/`uname -r`/extra"
ls /lib/modules/`uname -r`/extra >> $log
echo ""

echo "==============================="
echo "2. compile iptable with geoip  "
echo "==============================="

cd $dir/work

if [[ -d /usr/src/redhat/SOURCES/iptables-1.3.5 ]]
then
	rm -rf /usr/src/redhat/SOURCES/iptables-1.3.5
fi

rpm -ivh iptables-1.3.5-4.el5.src.rpm
tar xvfj /usr/src/redhat/SOURCES/iptables-1.3.5.tar.bz2 -C $srcDir/

cp -a $dir/work/geoip/iptables/extensions/libipt_geoip.* $srcDir/$ipt/extensions/
cp -a $dir/work/geoip/iptables/extensions/.geoip-test $srcDir/$ipt/extensions/

cd $srcDir/$ipt/

make clean
make KERNEL_DIR=/usr/src/kernels/$kver

ls $srcDir/$ipt/extensions | grep geo

cp -a $srcDir/$ipt/extensions/libipt_geoip.so /lib64/iptables/

echo "ls /lib64/iptables|grep geo" 

echo "" >> $log
echo "2. compile iptables with geoip " >> $log
ls /lib64/iptables|grep geo >> $log

echo "==============================="
echo "3. update GeoIP DB             "
echo "==============================="

cd $dir/work
tar xvfz csv2bin-20041103.tar.gz
cd ./csv2bin

if [[ -f csv2bin.o ]]
then
	make clean		
fi
make
cp -a csv2bin /usr/bin/

if [[ ! -d /var/geoip ]]
 then
        mkdir /var/geoip
        chmod 755 /var/geoip
        chown root.root /var/geoip
fi

cp $dir/work/GeoIPCountryCSV.zip /var/geoip/
cd /var/geoip
unzip -f GeoIPCountryCSV.zip
csv2bin ./GeoIPCountryWhois.csv

echo "" >> $log
echo "3. update GeoIP DB " >> $log

source $dir/work/geoip_update.sh >> $log

echo "==============================="
echo "4. iptables up                 "
echo "==============================="

source $dir/work/newfirewall.sh

echo "" >> $log
echo "4. iptables UP " >> $log

iptables -nL|grep country >>$log


echo "==============================="
echo "5. patch connlimit             "
echo "==============================="

if [[ -f $krDir/$kver/net/ipv4/netfilter/Makefile.org ]]
then
	cp -f $krDir/$kver/net/ipv4/netfilter/Makefile.org $krDir/$kver/net/ipv4/netfilter/Makefile
fi
cp $dir/work/patch-o-matic-ng-20090718.tar.bz2 $srcDir/
cd $srcDir
tar xvfj patch-o-matic-ng-20090718.tar.bz2
export KERNEL_DIR=/usr/src/kernels/$kver
export IPTABLES_DIR=$srcDir/$ipt

cd $srcDir/patch-o-matic-ng-20090718
./runme --download
./runme connlimit

cd $krDir/$kver
make oldconfig
make modules_prepare

cp -f net/ipv4/netfilter/Makefile net/ipv4/netfilter/Makefile.org
cp -f $dir/work/Makefile.new net/ipv4/netfilter/Makefile

make M=net/ipv4/netfilter/
cp net/ipv4/netfilter/ipt_connlimit.ko /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/
chmod 744 /lib/modules/`uname -r`/kernel/net/ipv4/netfilter/ipt_connlimit.ko
depmod -a
modprobe ipt_connlimit

echo "" >> $log
echo "5. patch connlimit " >> $log

lsmod | grep connlimit >> $log

/sbin/iptables -A INPUT -p tcp --syn --dport 80 -m connlimit --connlimit-above 30 -m recent --name badguy --set -j DROP

/sbin/iptables -nL|grep conn
/sbin/iptables -nL|grep country

