#!/bin/sh
#
#   +----------------------------------------------------------------------+
#   | Zend installation script                                             |
#   +----------------------------------------------------------------------+
#   | Copyright (c) 1998-2002 Zend Technologies Ltd.                       |
#   +----------------------------------------------------------------------+
#   | The contents of this source file is the sole property of             |
#   | Zend Technologies Ltd.  Unauthorized duplication or access is        |
#   | prohibited.                                                          |
#   +----------------------------------------------------------------------+
#   | Authors: Michael Spector <michael@zend.com>                          |
#   |          Anya Tarnyavsky <anya@zend.com>                             |
#   +----------------------------------------------------------------------+
#

INSTALL_DIR=./zui_files
PHP_SCRIPT=install.php
ZEND_TMPDIR=/tmp/zendinstall.$$

error ()
{
	echo "ERROR: "$1
	exit
}

# Try to guess who is running this script ?
ID="id -u"
MYUID=`$ID 2>/dev/null`

if [ -z "$MYUID" ];
then
	MYUID=`/usr/xpg4/bin/$ID 2>/dev/null`;
fi

if [ ! -z "$MYUID" ];
then
	if [ $MYUID != 0 ];
	then
		error "You need root privileges to run this script!";
	fi
fi

cleanup ()
{
	if [ ! -z "$ZEND_TMPDIR" ] && [ -d "$ZEND_TMPDIR" ];
	then
		rm -rf $ZEND_TMPDIR
	fi

	PHP_INI_SAVED=`ls $INSTALL_DIR/_*php.ini 2>/dev/null`
	if [ ! -z "$PHP_INI_SAVED" ];
	then
		# Restore your original PHP.ini file
		PHP_INI_ORIG=`basename $PHP_INI_SAVED | sed s/_/\//g`
		if [ ! -s $PHP_INI_ORIG -o `wc -c $PHP_INI_ORIG` -lt `wc -c $PHP_INI_SAVED` ];
		then
			rm -f $PHP_INI_ORIG
			mv $PHP_INI_SAVED $PHP_INI_ORIG
		fi
	fi

	stty echo
	clear
	echo
	echo "Installation script was aborted. The process was NOT completed successfully."
	echo
	exit 1
}

CALLING_SCRIPT=$0

#SYS_ORIG=`grep System ./data/_SYSTEM | cut -d '=' -f2`
#SYS_COMP=`uname`

#if [ $SYS_ORIG != $SYS_COMP ];
#then
#	error "Operation system doesn't match. Check if you have downloaded the correct package!";
#fi

cd $INSTALL_DIR 2>/dev/null || error "Cannot CD to install directory: "$INSTALL_DIR
if [ ! -f php.ini ];
then
	touch php.ini
	if [ -f ../data/ZendOptimizer.so ]; then
		echo 'zend_extension=../data/ZendOptimizer.so' >> php.ini
	fi
fi

# special support for darwin platform - must be done before executing PHP binary
if [ -f libdl.dylib ]; then
	# libdl.dylib exists, we need to install it.
	if [ ! -d /usr/local/lib ]; then
		mkdir -p /usr/local/lib 2>/dev/null || error "Cannot mkdir: /usr/local/lib"
	fi
	if [ ! -f /usr/local/lib/libdl.dylib ]; then
		cp -f libdl.dylib /usr/local/lib/libdl.dylib
	fi
fi

trap 'cleanup' 2 15
if [ ! -f ./php -o ! -x ./php ];
then
	error "Executable file: ./php doesn't exist in "$INSTALL_DIR
fi

# execute the main PHP script
ZEND_TMPDIR=$ZEND_TMPDIR CALLING_SCRIPT=$CALLING_SCRIPT ./php -q $PHP_SCRIPT $@

# end of install.sh
