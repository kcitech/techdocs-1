<?php
/*
   +----------------------------------------------------------------------+
   | ZendOptimizer installation script                                    |
   +----------------------------------------------------------------------+
   | Copyright (c) 1998-2003 Zend Technologies Ltd.                       |
   +----------------------------------------------------------------------+
   | The contents of this source file is the sole property of             |
   | Zend Technologies Ltd.  Unauthorized duplication or access is        |
   | prohibited.                                                          |
   +----------------------------------------------------------------------+
   | Authors: Michael Spector <michael@zend.com>                          |
   |          Anya Tarnyavsky <anya@zend.com>                             |
   +----------------------------------------------------------------------+
*/

include_once("install.inc");

$INSTALL =& new Install("Zend Optimizer", "2.5.7");

$argv = $_SERVER["argv"];
for($i=1; $i<count($argv); $i++) {
	if($argv[$i] == "--help" || $argv[$i] == "-h") {
		die("USAGE: ". $argv[0] ." [ --aix ]\n");
	}
	if($argv[$i] == "--aix") {
		$INSTALL->conf['uname']['sysname'] = "AIX";
	}
}

if($INSTALL->conf['uname']['sysname'] == "AIX") {
	$INSTALL->conf['license_file'] = "zend_optimizer.zl";
}

$INSTALL->set_components(array(
			"doc"                     =>  array ("%PREFIX%/doc", false),
			"zendid"                  =>  array ("%PREFIX%/bin", false),
			"ZendExtensionManager.so" =>  array ("%PREFIX%/lib", false),
			"poweredbyoptimizer.gif"  =>  array ("%PREFIX%/etc", false)
			));

$INSTALL->conf['supported_systems'] = array(
		"Linux" => array(
			"glibc" => array("2.1", "2.2")
			),
		"SunOS" => array(
			"machine" => array("sparc"),
			"release" => array("5.x")
			),
		"FreeBSD" => array(
			"release" => array("3.4", "4.x"),
			),
		"AIX" => array(
			"release" => array("4.x", "5.x"),
			)
		);

//$INSTALL->check_system_supported();

$INSTALL->welcome_box();
$INSTALL->license_agmnt_box();

if($INSTALL->conf['uname']['sysname'] == "AIX") {
	$INSTALL->find_license_on_disk($INSTALL->conf['license_file'], "Zend Optimizer");
}

$INSTALL->choose_install_prefix("/usr/local/Zend");
$INSTALL->php_ini_location_guess();

# Check for installed components:
$keep_existing = $INSTALL->check_installed_components(array( 
	array (
		"filename" => "ZendExtensionManager.so",
		"compname" => "extension_manager",
		"nicename" => "ZendExtensionManger"
	),
	array (
		"zemname" => "optimizer",
		"compname" => "optimizer",
		"nicename" => "ZendOptimizer"
	)
));

if(isset($keep_existing["extension_manager"])) {
	$INSTALL->remove_component ("ZendExtensionManager.so");
}


# PHP version detection - FROZEN

$using_apache = $INSTALL->is_using_apache();
if($using_apache){
	$apache_ver = $INSTALL->apache_get_version();
}

#if($using_apache) {
#	$INSTALL->php_type_guess(); /* Detect it just for Apache restart */
#}

if($INSTALL->conf['uname']['sysname'] == "AIX") {
	$INSTALL->php_version_remove("5.0.x");
}

if($INSTALL->conf['uname']['sysname'] == "Darwin" )
{
	$INSTALL->php_version_remove("4.0.6");
	$INSTALL->php_version_remove("4.1.x");
	$INSTALL->php_version_remove("4.2.0");
	$INSTALL->php_version_remove("4.2.x");
	$INSTALL->php_version_remove("4.3.x");
	$INSTALL->php_version_add("PHP 4.3.x ", "4.3.x ", 2);
}

$INSTALL->php_version_detect(true, true);

if($INSTALL->conf['uname']['sysname'] == "AIX") {

	$INSTALL->php_version_remove("4.0.6");

	if($using_apache && $INSTALL->conf['php_type'] == "module") {
		$optimizer_libname = "dyn/ZendOptimizer.so";
		$extension_manager_libname = "dyn/ZendExtensionManager.so";
	}
	else {
		$optimizer_libname = "stat/ZendOptimizer.so";
		$extension_manager_libname = "stat/ZendExtensionManager.so";
	}
	$INSTALL->remove_component("ZendExtensionManager.so");
	$INSTALL->add_component($extension_manager_libname,
			$INSTALL->make_path($INSTALL->conf['prefix'], "lib"), false);
}
else {
	$optimizer_libname = "ZendOptimizer.so";
}
$component_name = "optimizer";

$php_versions = $INSTALL->php_versions_get_array();
foreach ($php_versions as $php_ver) {

	$PHP_VER = preg_replace("/\./", "_", $php_ver);

	if(!isset($keep_existing["optimizer"])) {
		$INSTALL->add_component($PHP_VER."_comp/$optimizer_libname",
				$INSTALL->make_path($INSTALL->conf['prefix'], "lib",
					"Optimizer-".$INSTALL->get_component_version($component_name), "php-$php_ver"),
				false);
	}

	/* install Optimizer thread safety for PHP version >= 4.2.1 */
	if($INSTALL->ver_cmp($PHP_VER, "4.2.0")>0 && $INSTALL->conf['uname']['sysname'] != "AIX" && $INSTALL->conf['uname']['sysname'] != "Darwin" ){

		if(!isset($keep_existing["optimizer"])) {
			$INSTALL->add_component($PHP_VER."_comp/TS/$optimizer_libname",
					$INSTALL->make_path($INSTALL->conf['prefix'], "lib",
						"Optimizer_TS-".$INSTALL->get_component_version("$component_name-ts"), "php-$php_ver"),
					false);
		}

		if(!isset($keep_existing["extension_manager"])) {
			$INSTALL->add_component("ZendExtensionManager_TS.so",
								$INSTALL->make_path($INSTALL->conf['prefix'], "lib"), false);
		}
	}
}


$INSTALL->set_var_component("%PREFIX%", $INSTALL->conf['prefix']);
$INSTALL->php_ini_backup();

$INSTALL->start_install();

if($INSTALL->conf['uname']['sysname'] == "AIX") {
	$INSTALL->install_license();
}

/* do php.ini modifications */
$INSTALL->php_ini_open();

$INSTALL->php_ini_add_zend_section();

if($INSTALL->conf['uname']['sysname'] == "AIX") {
	$INSTALL->php_ini_add_path("zend.license_path", $INSTALL->conf['prefix']);
}

$INSTALL->php_ini_add_entry("zend_optimizer.optimization_level", 15);
$INSTALL->php_ini_add_zend_extension($INSTALL->conf['prefix']."/lib/ZendExtensionManager.so");

# Remove ZendOptimizer.so zend_extension entry before using ZendExtensionManager
$INSTALL->php_ini_remove_entry("ZendOptimizer.so");

if(!isset($keep_existing["optimizer"])) {
	$INSTALL->php_ini_add_entry("zend_extension_manager.optimizer",
			$INSTALL->make_path($INSTALL->conf['prefix'], "lib",
				"Optimizer-".$INSTALL->get_component_version($component_name)));
}

if($INSTALL->conf['uname']['sysname'] != "AIX" && $INSTALL->conf['uname']['sysname'] != "Darwin"){
	if(!isset($keep_existing["optimizer"])) {
		$INSTALL->php_ini_add_entry("zend_extension_manager.optimizer_ts",
				$INSTALL->make_path($INSTALL->conf['prefix'], "lib",
					"Optimizer_TS-".$INSTALL->get_component_version("$component_name-ts")));
	}

	if(!isset($keep_existing["extension_manager"])) {
		$INSTALL->php_ini_add_zend_extension($INSTALL->make_path($INSTALL->conf['prefix'], "lib",
					"ZendExtensionManager_TS".$INSTALL->conf['so_ext']), "zend_extension_ts");
	}
}

$INSTALL->php_ini_reorder();
$INSTALL->php_ini_fix();
$INSTALL->php_ini_close();

$INSTALL->php_ini_relocate();

if($INSTALL->conf['uname']['sysname'] == "AIX") {
	$httpd_user = $INSTALL->webserver_get_user();
	$INSTALL->add_permissions($INSTALL->conf['prefix']."/".$INSTALL->conf['license_file'], "0440", $httpd_user);
	$INSTALL->set_file_permissions();
}

$INSTALL->add_package_info();

/* There may be a case when PHP type is not detected, since php_type_guess() call is commented */
if(isset($INSTALL->conf['php_type']) && $INSTALL->conf['php_type'] == "executable"){
	$INSTALL->msgbox("The installation has completed successfully.");
}
else{
	$INSTALL->msgbox("The installation has completed successfully.\n".
			$INSTALL->conf['product']." is now ready for use.\n".
			"You must restart your Web server for the modifications to take effect.");

	if($INSTALL->conf['webserver'] == "Apache" && $INSTALL->yesnobox("Restart the Web server now?")){
		$INSTALL->webserver_restart();
	}
}

$INSTALL->cleanup();

?>
